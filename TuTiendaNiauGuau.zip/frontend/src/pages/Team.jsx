import React, {useState} from 'react'

export default function team() {
  return (
    <div className='d-flex justify-content-center align-items-center mt-5 mb-5'>

    </div>
  )
}
